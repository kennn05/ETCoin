from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file, Response
import os
from ETCoin.etc_wallet import Wallet, SERVER
import requests
import json
import hashlib
from werkzeug.utils import secure_filename
import time
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import qrcode
import base64

app = Flask(__name__)
app.secret_key = os.urandom(24)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.template_filter('ctime')
def ctime_filter(timestamp):
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))

def get_balance(address):
    res = requests.get(f"{SERVER}/balance/{address}")
    return res.json().get('balance', 0) if res.status_code == 200 else 0

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/create', methods=['GET', 'POST'])
def create():
    if request.method == 'POST':
        if 'generate' in request.form:
            wallet = Wallet().generate()
            session['temp_seed_phrase'] = wallet.seed_phrase
            return render_template('create.html', seed_phrase=wallet.seed_phrase)
        elif 'confirm' in request.form:
            username = request.form['username']
            pin = request.form['pin']
            try:
                wallet = Wallet().recover_from_seed(session['temp_seed_phrase'])
                wallet.username = username
                wallet._save_to_file(pin)
                session['address'] = wallet.address
                session['username'] = username
                session['wallet_file'] = f"{username}.wallet"
                session.pop('temp_seed_phrase', None)
                flash('Wallet created successfully! Download your wallet file from dashboard.', 'success')
                return redirect(url_for('dashboard'))
            except Exception as e:
                flash(str(e), 'error')
    return render_template('create.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        file = request.files['wallet_file']
        pin = request.form['pin']
        if file.filename == '':
            flash('No file selected', 'error')
            return render_template('login.html')
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        try:
            wallet = Wallet().load(file_path, pin)
            session['address'] = wallet.address
            session['username'] = wallet.username
            session['wallet_file'] = file_path
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash('Invalid file or PIN', 'error')
            os.remove(file_path)
    return render_template('login.html')

@app.route('/recover', methods=['GET', 'POST'])
def recover():
    if request.method == 'POST':
        seed_phrase = request.form['seed_phrase']
        username = request.form['username']
        pin = request.form['pin']
        try:
            wallet = Wallet().recover_from_seed(seed_phrase)
            wallet.username = username
            wallet._save_to_file(pin)
            session['address'] = wallet.address
            session['username'] = username
            session['wallet_file'] = f"{username}.wallet"
            flash('Wallet recovered successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(str(e), 'error')
    return render_template('recover.html')

@app.route('/dashboard')
def dashboard():
    if 'address' not in session:
        return redirect(url_for('login'))
    
    balance = get_balance(session['address'])
    
    # Fetch and filter pending transactions
    res_pending = requests.get(f"{SERVER}/tx/pending")
    pending_txs = res_pending.json() if res_pending.status_code == 200 else []
    user_address = session['address']
    filtered_pending_txs = []
    for tx in pending_txs:
        tx_data = {
            'sender': tx['sender'],
            'recipient': tx['recipient'],
            'amount': tx['amount'],
            'message': tx['message'],
            'timestamp': tx.get('timestamp', time.time())  # Fallback to current time if not provided
        }
        tx_hash = hashlib.sha256(json.dumps(tx_data, sort_keys=True).encode()).hexdigest()
        if tx['sender'] == user_address or tx['recipient'] == user_address:
            direction = "Outgoing" if tx['sender'] == user_address else "Incoming"
            filtered_pending_txs.append({
                'direction': direction,
                'sender': tx['sender'],
                'recipient': tx['recipient'],
                'amount': tx['amount'],
                'message': "User transaction",
                'tx_hash': tx_hash
            })
    filtered_pending_txs = list(reversed(filtered_pending_txs))  # Most recent first

    # Generate QR code
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(session['address'])
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")
    qr_buffer = BytesIO()
    qr_img.save(qr_buffer, format="PNG")
    qr_buffer.seek(0)
    qr_data = base64.b64encode(qr_buffer.getvalue()).decode('utf-8')
    
    return render_template('dashboard.html', balance=balance, address=session['address'], 
                         username=session['username'], qr_data=qr_data, pending_txs=filtered_pending_txs)

@app.route('/export_wallet')
def export_wallet():
    if 'address' not in session or 'wallet_file' not in session:
        return redirect(url_for('login'))
    return send_file(session['wallet_file'], as_attachment=True, download_name=f"{session['username']}.wallet")

@app.route('/view_private_key', methods=['GET', 'POST'])
def view_private_key():
    if 'address' not in session or 'wallet_file' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        pin = request.form['pin']
        try:
            wallet = Wallet().load(session['wallet_file'], pin)
            return render_template('view_private_key.html', private_key=wallet.private_key.to_pem().decode())
        except Exception as e:
            flash('Invalid PIN', 'error')
    return render_template('view_private_key.html')

@app.route('/view_seed_phrase', methods=['GET', 'POST'])
def view_seed_phrase():
    if 'address' not in session or 'wallet_file' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        pin = request.form['pin']
        try:
            wallet = Wallet().load(session['wallet_file'], pin)
            return render_template('view_seed_phrase.html', seed_phrase=wallet.seed_phrase)
        except Exception as e:
            flash('Invalid PIN', 'error')
    return render_template('view_seed_phrase.html')

@app.route('/send', methods=['GET', 'POST'])
def send():
    if 'address' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        recipient = request.form['recipient']
        try:
            amount = float(request.form['amount'])
            message = request.form.get('message', '')
            wallet = Wallet()
            wallet.address = session['address']
            
            result = wallet.send(recipient, amount, message)
            
            if result['status'] == 'error':
                flash(result['message'], 'error')
                return render_template('send.html')
            
            receipt_data = {
                'sender': wallet.address,
                'recipient': recipient,
                'amount': amount,
                'message': message,
                'tx_hash': result['tx_hash'],
                'timestamp': result['timestamp']
            }
            session['last_receipt'] = receipt_data
            flash('Transaction sent successfully!', 'success')
            return redirect(url_for('receipt'))
            
        except ValueError:
            flash('Invalid amount entered', 'error')
    return render_template('send.html')

@app.route('/receipt')
def receipt():
    if 'last_receipt' not in session:
        return redirect(url_for('dashboard'))
    return render_template('receipt.html', receipt=session['last_receipt'])

@app.route('/download_receipt')
def download_receipt():
    if 'last_receipt' not in session:
        return redirect(url_for('dashboard'))
    receipt = session['last_receipt']
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(100, 750, "ETCoin Transaction Receipt")
    c.drawString(100, 730, f"From: {receipt['sender']}")
    c.drawString(100, 710, f"To: {receipt['recipient']}")
    c.drawString(100, 690, f"Amount: {receipt['amount']} ETC")
    c.drawString(100, 670, f"Message: {receipt['message']}")
    c.drawString(100, 650, f"Transaction Hash: {receipt['tx_hash']}")
    c.drawString(100, 630, f"Timestamp: {receipt['timestamp']}")
    c.showPage()
    c.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"receipt_{receipt['tx_hash'][:8]}.pdf")

@app.route('/history', methods=['GET', 'POST'])
def history():
    if 'address' not in session:
        return redirect(url_for('login'))
    wallet = Wallet()
    wallet.address = session['address']
    filter_type = request.form.get('filter_type', 'all') if request.method == 'POST' else 'all'
    history = wallet.get_transaction_history(filter_type)
    return render_template('history.html', history=history, filter_type=filter_type)

@app.route('/block_viewer', methods=['GET', 'POST'])
def block_viewer():
    if 'address' not in session:
        return redirect(url_for('login'))
    res = requests.get(f"{SERVER}/chain")
    chain = res.json().get('chain', []) if res.status_code == 200 else []
    blocks = sorted(chain, key=lambda x: x['timestamp'], reverse=True)
    for block in blocks:
        block['block_hash'] = hashlib.sha256(json.dumps(block, sort_keys=True).encode()).hexdigest()
        for tx in block.get('transactions', []):
            tx_data = {
                'sender': tx['sender'],
                'recipient': tx['recipient'],
                'amount': tx['amount'],
                'message': tx['message'],
                'timestamp': block['timestamp']
            }
            tx['tx_hash'] = hashlib.sha256(json.dumps(tx_data, sort_keys=True).encode()).hexdigest()
    res_pending = requests.get(f"{SERVER}/tx/pending")
    pending_txs = res_pending.json() if res.status_code == 200 else []

    search_result = None
    search_type = None
    search_value = None

    if request.method == 'POST':
        search_type = request.form.get('search_type')
        search_value = request.form.get('search_value')
        wallet = Wallet()
        wallet.address = session['address']
        result, transactions = wallet._global_search(chain, pending_txs, search_type, search_value)
        
        if search_type == 'address' and result is not None:
            search_result = {'balance': result, 'transactions': transactions}
        elif search_type == 'index' and result is not None:
            search_result = result
        elif search_type == 'hash' and result is not None:
            search_result = result

    return render_template('block_viewer.html', blocks=blocks, search_result=search_result, 
                         search_type=search_type, search_value=search_value)

@app.route('/pending_transactions')
def pending_transactions():
    if 'address' not in session:
        return redirect(url_for('login'))
    res = requests.get(f"{SERVER}/tx/pending")
    pending_txs = res.json() if res.status_code == 200 else []
    pending_txs = list(reversed(pending_txs))
    return render_template('pending_transactions.html', transactions=pending_txs)

@app.route('/logout')
def logout():
    # Delete the wallet file from the server if it exists
    if 'wallet_file' in session:
        wallet_file_path = session['wallet_file']
        if os.path.exists(wallet_file_path):
            try:
                os.remove(wallet_file_path)
            except Exception as e:
                flash(f'Error deleting wallet file: {str(e)}', 'error')
            # No flash message on successful deletion

    # Clear session data
    session.pop('address', None)
    session.pop('username', None)
    session.pop('wallet_file', None)
    session.pop('last_receipt', None)
    session.pop('temp_seed_phrase', None)
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

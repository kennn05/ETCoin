// Add any interactive features here if needed
console.log("ETCoin Web Loaded");
